"""Repository 抽象层。

W1 阶段定义接口契约，不含任何实现。W2 / W3 分别实现 SQLite / MySQL。
所有方法必须带 ``user_id`` 参数（共享缓存除外），强制数据隔离。

关联方案: docs/方案_数据层扩展_v2.2.md §14 W1.1
"""
from __future__ import annotations

from typing import Any, Optional, Protocol, runtime_checkable

from ielts_buddy.core.models import (
    ExamReport,
    ExamSession,
    GradeResult,
    LearningRecord,
    PersonalWord,
    VocabCategory,
    Word,
)


# =============================================================
# 1. LearningRepository — 学习记录 + 艾宾浩斯复习
# =============================================================


@runtime_checkable
class LearningRepository(Protocol):
    """学习记录仓储接口。

    设计要点：
      - 所有方法都带 ``user_id: int``，强制数据隔离
      - 读写分离：``record_*`` / ``upsert_*`` 走写；``get_*`` 走只读
      - 返回 Pydantic 模型，不返回 ``sqlite3.Row`` / ``dict``
    """

    # ---- 单条记录 ----
    def get_record(self, user_id: int, word: str) -> Optional[LearningRecord]:
        """获取单词的学习记录；不存在则返回 None。"""
        ...

    def upsert_record(
        self,
        user_id: int,
        word: Word,
        correct: bool,
        source: str = "builtin",
    ) -> LearningRecord:
        """插入或更新学习记录，自动推进艾宾浩斯 level。"""
        ...

    def toggle_star(self, user_id: int, word: str) -> bool:
        """切换收藏状态，返回切换后的值。"""
        ...

    def toggle_difficult(self, user_id: int, word: str) -> bool:
        """切换"难词"标记，返回切换后的值。"""
        ...

    # ---- 复习计划 ----
    def get_due_words(self, user_id: int, limit: int = 20) -> list[dict]:
        """获取到期需复习的单词。"""
        ...

    def get_due_count(self, user_id: int) -> int:
        """到期单词数量。"""
        ...

    def get_history(self, user_id: int, days: int = 30) -> list[dict]:
        """最近 N 天的学习活动（每日聚合）。"""
        ...

    # ---- 全量查询 ----
    def get_all_records(self, user_id: int) -> list[LearningRecord]:
        """该用户全部学习记录。"""
        ...

    def get_learned_count(self, user_id: int) -> int:
        """已学过的单词总数（去重）。"""
        ...

    def get_learned_words_today(self, user_id: int) -> list[str]:
        """今日新学的单词列表。"""
        ...

    # ---- 错词本 (v3.6 新增) ----
    def get_wrong_words(
        self,
        user_id: int,
        min_wrong: int = 1,
        days: int | None = None,
        limit: int = 200,
    ) -> list[dict]:
        """按 wrong_count 降序返回错词列表。

        Args:
            user_id: 用户隔离
            min_wrong: 至少错 N 次（默认 1 = 任何错过的都返回）
            days: 仅看最近 N 天 last_reviewed；None = 不限时间
            limit: 最多返回条数

        Returns:
            list[dict] 按 ``wrong_count DESC, last_reviewed DESC`` 排序,
            每个 dict 含 learning_records 表所有字段(word / word_data / wrong_count / ...)
        """
        ...

    def reset_mistake(self, user_id: int, word: str) -> bool:
        """重置错词状态:wrong_count 清 0,correct_count +1(标记已掌握)。

        用于"标记为已掌握"按钮。与 upsert_record 不同,不会增加 learn_count
        (因为本次不是答题),仅校 wrong_count / memory_level。
        """
        ...

    def get_mistake_stats(self, user_id: int) -> dict:
        """错词本聚合统计：total_mistakes / total_wrong_count / recent_7d 等。

        Returns:
            {
                "distinct_words": int,        # 错过的不同词数（wrong_count>0）
                "total_wrong_count": int,     # 所有 wrong_count 累加
                "last_7d_wrong": int,         # 最近 7 天新发生错误的次数
                "top_offenders": list[dict],  # wrong_count 前 5 名
            }
        """
        ...

    # ---- 口语对练错词回收（v3.7 P1 新增）----
    def record_speaking_error(
        self,
        user_id: int,
        word: str,
        source: str = "speaking",
    ) -> bool:
        """口语对练中识别出来的错词或重点词 → 落到 learning_records.wrong_count +1。

        与 upsert_record 的差异：不会推进 memory_level(口语错词不算"学过",
        仅是错误信号)。如果用户从未学过该词,新建一条 learning_records 行,
        wrong_count=1 / correct_count=0 / memory_level=0。

        Args:
            user_id: 用户 ID(隔离)。
            word: 目标单词(大小写不敏感,存库用 .lower())。
            source: 错误来源标记,目前固定为 "speaking"。

        Returns:
            True 表示插入/更新成功(rowcount > 0)。
        """
        ...


# =============================================================
# 2. PersonalVocabRepository — 个人词库 + 分类
# =============================================================


@runtime_checkable
class PersonalVocabRepository(Protocol):
    """个人词库仓储接口。

    包含：单词 CRUD、分类管理、错词自动收录、批量导入导出。
    """

    # ---- 单词 CRUD ----
    def add_word(self, user_id: int, pw: PersonalWord) -> int:
        """新增单词，返回新行 id。"""
        ...

    def edit_word(self, user_id: int, word_name: str, **kwargs: Any) -> PersonalWord:
        """编辑单词字段；返回更新后的实例。"""
        ...

    def delete_word(self, user_id: int, word_name: str) -> bool:
        """删除单词，返回是否成功。"""
        ...

    def get_word(self, user_id: int, word_name: str) -> Optional[PersonalWord]:
        """获取单词详情；不存在返回 None。"""
        ...

    def list_words(
        self,
        user_id: int,
        category: Optional[str] = None,
        page: int = 1,
        per_page: int = 20,
    ) -> tuple[list[PersonalWord], int]:
        """分页列出单词，返回 (列表, 总数)。"""
        ...

    def get_word_count(self, user_id: int) -> int:
        """个人词库单词总数。"""
        ...

    # ---- 分类管理 ----
    def create_category(
        self,
        user_id: int,
        name: str,
        description: str = "",
    ) -> VocabCategory:
        """创建分类。"""
        ...

    def delete_category(self, user_id: int, name: str) -> bool:
        """删除分类（系统分类 is_system=1 禁止删除）。"""
        ...

    def list_categories(self, user_id: int) -> list[VocabCategory]:
        """列出该用户的所有分类（含系统分类）。"""
        ...

    def add_to_category(
        self,
        user_id: int,
        word: str,
        category: str,
    ) -> bool:
        """把单词加入分类。"""
        ...

    def remove_from_category(
        self,
        user_id: int,
        word: str,
        category: str,
    ) -> bool:
        """从分类移除单词。"""
        ...

    def get_word_categories(
        self,
        user_id: int,
        word: str,
    ) -> list[VocabCategory]:
        """获取单词所属的所有分类。"""
        ...

    # ---- 特殊方法 ----
    def add_mistake(
        self,
        user_id: int,
        word: Word | PersonalWord,
        source: str = "quiz_mistake",
    ) -> PersonalWord:
        """收录错词到 mistakes 分类。"""
        ...

    def add_from_grading(
        self,
        user_id: int,
        word: str,
        context: str = "",
        suggestion: str = "",
        comment: str = "",
    ) -> PersonalWord:
        """从批改结果收录词汇。"""
        ...

    # ---- 统计 ----
    def get_source_distribution(self, user_id: int) -> dict[str, int]:
        """按来源统计单词数。"""
        ...

    def get_band_distribution(self, user_id: int) -> dict[int, int]:
        """按 Band 统计单词数。"""
        ...

    # ---- 导入导出 ----
    def import_words(
        self,
        user_id: int,
        file_path: Any,
        vocab_service: Any = None,
    ) -> dict[str, int]:
        """从文件导入单词，返回 {'success': N, 'failed': M}。"""
        ...

    def export_words(
        self,
        user_id: int,
        fmt: str = "json",
        category: Optional[str] = None,
    ) -> str:
        """导出为 JSON / CSV / 纯文本，返回文件内容字符串。"""
        ...


# =============================================================
# 3. ExamRepository — 模拟考试
# =============================================================


@runtime_checkable
class ExamRepository(Protocol):
    """模拟考试仓储接口。"""

    def create_exam(
        self,
        user_id: int,
        band: int,
        count: int,
        time_limit: int = 20,
    ) -> ExamSession:
        """创建一场模拟考试。"""
        ...

    def submit_answer(
        self,
        user_id: int,
        session_id: str,
        q_index: int,
        answer: str,
    ) -> dict:
        """提交一题答案，返回判分结果 {'correct': bool, 'answer': str}。"""
        ...

    def finish_exam(self, user_id: int, session_id: str) -> ExamReport:
        """完成考试，生成报告。"""
        ...

    def get_exam_history(
        self,
        user_id: int,
        limit: int = 20,
    ) -> list[dict]:
        """获取历史考试记录。"""
        ...

    def get_exam_session(
        self,
        user_id: int,
        session_id: str,
    ) -> Optional[ExamSession]:
        """获取考试会话详情（含题目）。"""
        ...


# =============================================================
# 4. GradeRepository — AI 写作批改历史
# =============================================================


@runtime_checkable
class GradeRepository(Protocol):
    """批改结果仓储接口。"""

    def save_result(self, user_id: int, result: GradeResult) -> int:
        """保存批改结果，返回新行 id。"""
        ...

    def get_history(
        self,
        user_id: int,
        limit: int = 20,
        task_type: Optional[str] = None,
    ) -> list[GradeResult]:
        """获取批改历史，task_type 可选 'task1_academic' / 'task1_general' / 'task2'。"""
        ...

    def get_average_score(self, user_id: int) -> float:
        """平均分。"""
        ...

    def get_error_trend(self, user_id: int, limit: int = 10) -> list[dict]:
        """错误类型趋势。"""
        ...


# =============================================================
# 5. VocabCacheRepository — 大词库缓存
# =============================================================


@runtime_checkable
class VocabCacheRepository(Protocol):
    """词库缓存仓储接口。

    注：缓存层不带 ``user_id``（所有用户共享同一份词库）。
    只缓存内置词库（526 精选 / 4485 大词库），不存用户数据。
    """

    def get_cached(self, word: str) -> Optional[dict]:
        """读取缓存的词条；不存在返回 None。"""
        ...

    def put_cached(
        self,
        word: str,
        band: int,
        topic: str,
        payload: dict,
    ) -> None:
        """写入缓存。"""
        ...

    def get_mtime(self, key: str) -> str:
        """获取缓存元数据的 mtime。"""
        ...

    def set_mtime(self, key: str, value: str) -> None:
        """设置缓存元数据的 mtime。"""
        ...

    def clear_cache(self) -> None:
        """清空缓存（用于强制重建）。"""
        ...


# =============================================================
# 6. UserRepository — 用户表（仅联网模式用）
# =============================================================


@runtime_checkable
class UserRepository(Protocol):
    """用户表仓储接口。

    单机模式下 SQLite 实现为 no-op（固定返回 ``user_id=1``）。
    联网模式下走 MySQL，处理 ``username`` -> ``user_id`` 映射。
    """

    def get_or_create(self, username: str) -> int:
        """根据 username 获取或创建用户，返回 user_id。"""
        ...

    def get_by_id(self, user_id: int) -> Optional[dict]:
        """根据 user_id 获取用户信息（含 username / created_at / last_login_at）。"""
        ...

    def update_last_login(self, user_id: int) -> None:
        """更新 last_login_at 为当前时间。"""
        ...

    def list_users(self) -> list[dict]:
        """列出所有用户（仅联网模式有效）。"""
        ...

    # ---- 种子分类（3-A 决策） ----
    def ensure_system_categories(self, user_id: int) -> None:
        """用户首次进入联网模式时，从 user_id=0 模板复制系统分类。

        单机模式实现为 no-op；联网模式实现为
        ``INSERT INTO vocab_categories (user_id, name, ...) SELECT :uid, name, ... FROM vocab_categories WHERE user_id = 0``。
        """
        ...


# =============================================================
# 7. SpeakingPracticeRepository — 口语对练历史（v3.7 P1 新增）
# =============================================================


@runtime_checkable
class SpeakingPracticeRepository(Protocol):
    """口语对练历史仓储接口。

    对应 ``speaking_practice_records`` 表。每条记录 = 一次完整的
    「抽题 → 录音 → 转写 → LLM 评分 → 错词回收」流程。
    """

    def create_practice_record(
        self,
        user_id: int,
        session_id: str,
        part: int,
        topic_id: Optional[int],
        topic_name: str,
        question: str,
        audio_path: Optional[str],
        audio_duration_sec: float,
        audio_mime: str = "audio/webm",
    ) -> int:
        """创建新对练记录,返回新行 id。score/transcript 等字段留空,后续 update 填。"""
        ...

    def update_practice_transcript(
        self,
        user_id: int,
        session_id: str,
        transcript: str,
        transcript_tokens: Optional[list[dict]] = None,
        whisper_model: str = "small.en",
        used_core_ml: bool = True,
    ) -> bool:
        """转写完后回填 transcript + tokens。"""
        ...

    def update_practice_score(
        self,
        user_id: int,
        session_id: str,
        scores: dict,
        word_errors: list[dict],
        grammar_errors: list[dict],
        highlights: list[str],
        suggestions: list[str],
        score_fallback: bool = False,
    ) -> bool:
        """LLM 评完分后回填 4 个 JSON 字段。"""
        ...

    def get_practice_record(
        self,
        user_id: int,
        record_id: int,
    ) -> Optional[dict]:
        """按 record_id 取单条详情(限当前用户)。"""
        ...

    def get_practice_by_session(
        self,
        user_id: int,
        session_id: str,
    ) -> Optional[dict]:
        """按 session_id 取一条记录(浏览器提交后回查用)。"""
        ...

    def list_practice_history(
        self,
        user_id: int,
        part: Optional[int] = None,
        page: int = 1,
        size: int = 20,
    ) -> tuple[list[dict], int]:
        """分页列历史,按 created_at DESC。返回 (items, total)。"""
        ...

    def set_audio_null(self, user_id: int, session_id: str) -> bool:
        """7 天清理时,把 audio_path 设为 NULL(保留记录行,音频文件物理删)。"""
        ...

    def list_expired_audio_paths(
        self,
        retention_days: int,
    ) -> list[tuple[int, str, str]]:
        """返回所有 retention_days 天前的录音记录 (user_id, session_id, audio_path)。

        Service 层据此删除文件 + 调 set_audio_null 把 DB 标记置空。
        """
        ...

    def delete_old_records_keeping_audio_path(
        self,
        cutoff_days: int,
    ) -> int:
        """可选的策略:清掉 cutoff_days 天前且 audio_path 已 NULL 的整行。
        本次 MVP 不调用,留接口。返回删除行数。"""
        ...


# =============================================================
# 8. ListeningPracticeRepository — 真·听力题库(v3.7 P2 新增)
# =============================================================


@runtime_checkable
class ListeningPracticeRepository(Protocol):
    """真·听力题库仓储协议。

    SQLite / MySQL 实现各有同名类,签名完全一致。
    """

    # ---- 题库 ----
    def seed_question(
        self,
        section: int,
        set_id: int,
        qid: int,
        scenario: str,
        question_type: str,
        stem: str,
        options: Optional[list[str]],
        answer: str,
        explanation: str,
        transcript: str,
        audio_path: Optional[str] = None,
        audio_generated_at: Optional[str] = None,
    ) -> int:
        """插入或更新一道题(UNIQUE(section, set_id, qid) 兜底 upsert)。"""
        ...

    def get_question(self, question_id: int) -> Optional[dict]:
        """单题详情(含 options 已 parse)。"""
        ...

    def list_sections_with_counts(self) -> list[dict]:
        """返回 [{section, total_sets, total_questions}]。"""
        ...

    def list_sets_by_section(self, section: int) -> list[dict]:
        """返回该 Section 下每套的元信息。"""
        ...

    def list_questions_by_set(
        self, section: int, set_id: int
    ) -> list[dict]:
        """按 qid 排序返回该套所有题。"""
        ...

    def set_audio_path(
        self,
        question_id: int,
        audio_path: Optional[str],
        audio_generated_at: Optional[str],
    ) -> None:
        """TTS 合成后回填 audio_path + audio_generated_at。"""
        ...

    def count_questions(self) -> int:
        """总题数(用于启动期判断是否需要种子)。"""
        ...

    # ---- 答题记录 ----
    def record_attempt(
        self,
        user_id: int,
        question_id: int,
        user_answer: str,
        is_correct: bool,
        duration_sec: float = 0.0,
        played_count: int = 1,
    ) -> int:
        """记录一次答题;返回 attempt id。"""
        ...

    def list_user_attempts(
        self,
        user_id: int,
        page: int = 1,
        size: int = 20,
        section: Optional[int] = None,
    ) -> tuple[list[dict], int]:
        """返回 (items, total)。section 过滤会 JOIN listening_questions。"""
        ...

    def get_user_stats(self, user_id: int) -> dict:
        """返回 {total_attempts, correct_count, accuracy, by_section}。"""
        ...

    # ---- 清理 ----
    def list_expired_audio_paths(
        self,
        retention_days: int,
    ) -> list[tuple[int, str]]:
        """返回所有 retention_days 天前生成的音频 (question_id, audio_path)。"""
        ...


# =============================================================
# 9. RepositoryContainer — 8 个 Repository 的容器
# =============================================================


@runtime_checkable
class PrepResourceRepository(Protocol):
    """备考资源广场仓储接口（v3.8 新增）。

    跨用户共享的 B 站资源元数据,不在 SYNC_TABLES。
    """

    def seed_resource(
        self,
        title: str,
        bv_id: str,
        url: str,
        author_name: str,
        skill: str,
        video_type: str,
        level: str,
        method_summary: str,
        source_status: str,
        author_uid: Optional[int] = None,
        uploader_name: Optional[str] = None,
        uploader_uid: Optional[int] = None,
        publish_date: Optional[str] = None,
        duration_sec: int = 0,
        outdated_risk: str = "low",
        format_compatible: str = "computer",
        computer_delivery_only: bool = True,
        is_featured: bool = False,
        recommend_score: float = 0.0,
        sort_order: int = 100,
        related_action_url: Optional[str] = None,
        related_action_label: Optional[str] = None,
    ) -> int:
        """插入或更新一条资源(UNIQUE bv_id 兜底 upsert)。"""
        ...

    def get_resource(self, resource_id: int) -> Optional[dict]:
        """单条资源详情。"""
        ...

    def get_resource_by_bv(self, bv_id: str) -> Optional[dict]:
        """按 B 站 BV 号查询(防重复种子)。"""
        ...

    def list_resources(
        self,
        skill: Optional[str] = None,
        level: Optional[str] = None,
        source_status: Optional[str] = None,
        is_featured: Optional[bool] = None,
        sort_by: str = "recommend_score",  # recommend_score / sort_order / publish_date
        limit: int = 50,
        offset: int = 0,
    ) -> list[dict]:
        """按多条件过滤 + 排序 + 分页。"""
        ...

    def list_featured(self, skill: Optional[str] = None, limit: int = 5) -> list[dict]:
        """列出顶置资源(is_featured=1)。"""
        ...

    def list_by_up(self, author_name: str, limit: int = 20) -> list[dict]:
        """列出某 UP 主的所有资源。"""
        ...

    def count_resources(
        self,
        skill: Optional[str] = None,
        level: Optional[str] = None,
        source_status: Optional[str] = None,
        is_featured: Optional[bool] = None,
    ) -> int:
        """资源总数(支持 skill / level / source_status / is_featured 过滤)。"""
        ...

    def update_resource(self, resource_id: int, **kwargs: Any) -> bool:
        """更新任意字段(只更新传入的非 None 值)。"""
        ...

    def delete_resource(self, resource_id: int) -> bool:
        """删除资源(谨慎用,前台目前不暴露)。"""
        ...

    def list_distinct_ups(self) -> list[dict]:
        """列出所有 UP 主 + 资源数。"""
        ...


@runtime_checkable
class ReadingPracticeRepository(Protocol):
    """Reading 真题题库仓储接口（v3.8 新增）。"""

    # ---- 题库 ----
    def seed_passage(
        self,
        section: str,
        set_id: int,
        qid: int,
        passage_number: int,
        title: str,
        topic: str,
        question_type: str,
        passage_text: str,
        stem: str,
        options: Optional[list[str]],
        answer: str,
        explanation: str,
        word_count: int = 0,
        source_line: Optional[int] = None,
    ) -> int:
        """插入或更新一道题(UNIQUE(section, set_id, qid) 兜底 upsert)。"""
        ...

    def get_passage(self, question_id: int) -> Optional[dict]:
        """单题详情(含 options 已 parse)。"""
        ...

    def list_sections_with_counts(self) -> list[dict]:
        """返回 [{section, total_sets, total_passages}]。"""
        ...

    def list_sets_by_section(self, section: str) -> list[dict]:
        """返回该 Section 档位下每套的元信息。"""
        ...

    def list_passages_by_set(self, section: str, set_id: int) -> list[dict]:
        """按 qid 排序返回该套所有题。"""
        ...

    def count_passages(self) -> int:
        """总题数(用于启动期判断是否需要种子)。"""
        ...

    # ---- 答题记录 ----
    def record_attempt(
        self,
        user_id: int,
        question_id: int,
        user_answer: str,
        is_correct: bool,
        duration_sec: float = 0.0,
    ) -> int:
        """记录一次答题;返回 attempt id。"""
        ...

    def list_user_attempts(
        self,
        user_id: int,
        page: int = 1,
        size: int = 20,
        section: Optional[str] = None,
    ) -> tuple[list[dict], int]:
        """返回 (items, total)。"""
        ...

    def get_user_stats(self, user_id: int) -> dict:
        """返回 {total_attempts, correct_count, accuracy, by_section}。"""
        ...


# =============================================================


@runtime_checkable
class RepositoryContainer(Protocol):
    """10 个 Repository 的聚合(v3.8 新增 PrepResource + Reading)。

    ``db_factory.create_repositories()`` 返回此接口的实现。
    Services 接受一个 ``RepositoryContainer`` 注入。
    """

    learning: LearningRepository
    personal_vocab: PersonalVocabRepository
    exam: ExamRepository
    grade: GradeRepository
    vocab_cache: VocabCacheRepository
    user: UserRepository
    speaking_practice: SpeakingPracticeRepository
    listening_practice: ListeningPracticeRepository
    prep_resource: PrepResourceRepository
    reading_practice: ReadingPracticeRepository

    def close(self) -> None:
        """关闭所有底层连接（SQLite / MySQL 连接池）。"""
        ...


# =============================================================
# 8. 运行时断言工具
# =============================================================


def assert_repository_implements_protocol(
    instance: Any,
    protocol: type,
) -> None:
    """运行时检查 ``instance`` 是否满足 ``protocol`` 接口。

    用于 W3 阶段：``db_factory`` 创建的 Repository 集合应当通过此断言，
    确保实现完整，缺失方法立即 fail-fast。

    Args:
        instance: 待检查的实例。
        protocol: 目标 Protocol 类。

    Raises:
        TypeError: 如果 ``instance`` 缺少 ``protocol`` 要求的方法。
    """
    if not isinstance(instance, protocol):
        missing = _find_missing_methods(instance, protocol)
        raise TypeError(
            f"{type(instance).__name__} 未实现 {protocol.__name__}，"
            f"缺失方法: {missing}"
        )


def _find_missing_methods(instance: Any, protocol: type) -> list[str]:
    """找出 ``instance`` 缺失的 protocol 方法。"""
    proto_methods = {
        name
        for name in dir(protocol)
        if not name.startswith("_") and callable(getattr(protocol, name, None))
    }
    impl_methods = set(dir(instance))
    return sorted(proto_methods - impl_methods)


__all__ = [
    "LearningRepository",
    "PersonalVocabRepository",
    "ExamRepository",
    "GradeRepository",
    "VocabCacheRepository",
    "UserRepository",
    "SpeakingPracticeRepository",
    "ListeningPracticeRepository",
    "PrepResourceRepository",
    "ReadingPracticeRepository",
    "RepositoryContainer",
    "assert_repository_implements_protocol",
]
