"""vocab 命令组：随机单词、测验、复习、搜索、浏览、个人词库管理"""

from __future__ import annotations

import math
import random as rand_mod

import click
from rich.console import Console
from rich.panel import Panel
from rich.table import Table

from ielts_buddy.core.models import PersonalWord
from ielts_buddy.core.config import Config, get_mode
from ielts_buddy.repositories import create_repositories
from ielts_buddy.services.auth_service import AuthService, NotLoggedInError
from ielts_buddy.services.personal_vocab_service import PersonalVocabService
from ielts_buddy.services.review_service import ReviewService
from ielts_buddy.services.vocab_service import VocabService

console = Console()


def _load_vocab(source: str) -> VocabService:
    """根据 source 参数加载词库"""
    svc = VocabService()
    if source == "curated":
        svc.load_all()
    else:
        svc.load_master()
    return svc


# 共享的 --source 选项
_source_option = click.option(
    "-s", "--source",
    type=click.Choice(["master", "curated"], case_sensitive=False),
    default="master",
    help="词库来源: master=大词库(4485词), curated=精选(526词)",
    show_default=True,
)


@click.group("vocab")
def vocab():
    """词汇学习命令"""


@vocab.command()
@click.option("-n", "--count", default=5, help="抽取数量", show_default=True)
@click.option("-b", "--band", type=int, default=None, help="按 band 等级筛选 (5-9)")
@click.option(
    "--learn/--no-learn",
    "record_learn_flag",
    default=True,
    help="是否按 web 学习模式（认识/不认识 + 艾宾浩斯记录）。默认开启；--no-learn 仅展示。",
    show_default=True,
)
@_source_option
def random(count: int, band: int | None, source: str, record_learn_flag: bool):
    """随机抽取单词（对齐 web /study/random：可标记认识/不认识并记录到复习曲线）"""
    svc = _load_vocab(source)

    # ---- 登录态校验（仅在需要写记录时） ----
    user_id: int | None = None
    if record_learn_flag:
        try:
            auth = AuthService()
            try:
                user_id = auth.get_current_user_id()
                if user_id is None:
                    raise NotLoggedInError("未登录")
            finally:
                auth.close()
        except NotLoggedInError:
            console.print(
                "[red]当前未登录，无法记录学习结果。[/red]\n"
                "请先执行：[bold cyan]ib login <用户名>[/bold cyan]"
            )
            return

    # ---- 抽样（尽量避开已学过的词；不足时回退到全量） ----
    candidates = svc.random_words(count, band)
    if not candidates:
        console.print("[yellow]没有找到匹配的单词。[/yellow]")
        return

    if record_learn_flag and user_id is not None:
        try:
            container = create_repositories(mode=get_mode(Config()))
            learned = set(container.learning.get_learned_words(user_id))
            unseen = [w for w in candidates if w.word not in learned]
            container.close()
            words = unseen if unseen else candidates
        except Exception:
            words = candidates
    else:
        words = candidates

    source_label = "大词库" if source == "master" else "精选"
    table = Table(title=f"随机单词 (共 {len(words)} 个) [{source_label}]", show_lines=True)
    table.add_column("单词", style="bold cyan", min_width=15)
    table.add_column("音标", style="dim")
    table.add_column("词性", style="green", justify="center")
    table.add_column("释义", style="yellow", min_width=15)
    table.add_column("Band", justify="center")
    table.add_column("主题", style="magenta")

    for w in words:
        table.add_row(w.word, w.phonetic, w.pos, w.meaning, str(w.band), w.topic)

    console.print(table)

    # ---- 仅展示模式（--no-record）：保持原有行为 ----
    if not record_learn_flag:
        for w in words:
            parts = []
            parts.append(f"[bold cyan]{w.word}[/bold cyan]  {w.phonetic}  [green]{w.pos}[/green]")
            parts.append(f"[yellow]{w.meaning}[/yellow]")
            if w.example:
                parts.append(f"\n[italic]例: {w.example}[/italic]")
                if w.example_cn:
                    parts.append(f"[dim]    {w.example_cn}[/dim]")
            if w.collocations:
                parts.append(f"\n搭配: {', '.join(w.collocations)}")
            if w.synonyms:
                parts.append(f"同义: {', '.join(w.synonyms)}")
            if w.etymology:
                parts.append(f"词源: {w.etymology}")

            console.print(Panel("\n".join(parts), border_style="blue"))
        return

    # ---- 学习模式：逐词询问 认识/不认识，写入复习曲线 ----
    review = ReviewService(user_id=user_id)
    try:
        due_count_fn = review.get_due_count
        initial_due = due_count_fn()
    except Exception:
        initial_due = None

    console.print(
        f"\n[bold]随机学习[/bold]  共 {len(words)} 个  "
        f"[dim]y=认识  n=不认识  s=跳过(不记录)  q=退出[/dim]\n"
    )

    known = 0
    unknown = 0
    skipped = 0
    answered = 0
    total = len(words)

    try:
        for i, w in enumerate(words, 1):
            console.print(
                f"[bold cyan]({i}/{total}) {w.word}[/bold cyan]  "
                f"{w.phonetic}  [green]{w.pos}[/green]"
            )
            console.print(f"  释义: [yellow]{w.meaning}[/yellow]")
            if w.example:
                console.print(f"  [italic]例: {w.example}[/italic]")
            if w.collocations:
                console.print(f"  搭配: [dim]{', '.join(w.collocations)}[/dim]")

            try:
                answer = input("  认识吗？[bold](Y/n/s/q)[/bold]: ").strip().lower()
            except EOFError:
                console.print("\n[dim]已中断[/dim]")
                break

            if answer in ("q", "quit"):
                console.print("[dim]已退出本次学习。[/dim]")
                break
            if answer in ("s", "skip"):
                skipped += 1
                console.print("  [dim]跳过，未记录[/dim]\n")
                continue

            # 默认（空 / y / yes）= 认识；其他 = 不认识
            is_correct = answer in ("", "y", "yes")

            try:
                review.record_learn(w, is_correct, source="cli_random")
            except Exception as e:  # noqa: BLE001 - 记录失败仅提示，不中断流程
                console.print(f"  [red]记录失败：{e}[/red]")
                continue

            answered += 1
            if is_correct:
                known += 1
                console.print("  [green]✓ 已记录为 认识[/green]\n")
            else:
                unknown += 1
                console.print(
                    "  [red]✗ 已记录为 不认识[/red]  "
                    "[dim]→ 进入待复习（艾宾浩斯曲线）[/dim]\n"
                )
    except KeyboardInterrupt:
        console.print("\n[dim]学习中断[/dim]")

    review.close()

    # ---- 完成总结 ----
    console.print(
        f"\n[bold]本次学习总结[/bold]  "
        f"回答 {answered} 个  "
        f"[green]认识 {known}[/green]  "
        f"[red]不认识 {unknown}[/red]  "
        f"[dim]跳过 {skipped}[/dim]"
    )
    try:
        review2 = ReviewService(user_id=user_id)
        try:
            new_due = review2.get_due_count()
            if initial_due is not None:
                delta = new_due - initial_due
                if delta > 0:
                    console.print(
                        f"[dim]待复习 +{delta}（当前共 {new_due} 个待复习）[/dim]"
                    )
                else:
                    console.print(f"[dim]当前共 {new_due} 个待复习[/dim]")
        finally:
            review2.close()
    except Exception:
        pass

    console.print(
        "[dim]提示：学习记录将在 ~30s 后自动同步到 web 端，"
        "届时可在仪表盘的『今日新学』『今日复习』中看到。[/dim]"
    )


@vocab.command()
@click.option("-n", "--count", default=10, help="题目数量", show_default=True)
@click.option("-b", "--band", type=int, default=None, help="按 band 等级筛选")
@click.option(
    "-m", "--mode",
    type=click.Choice(["en2zh", "zh2en", "mix"], case_sensitive=False),
    default="en2zh",
    help="测验模式: en2zh=英译中, zh2en=中译英, mix=混合",
    show_default=True,
)
@_source_option
def quiz(count: int, band: int | None, mode: str, source: str):
    """词汇测验"""
    svc = _load_vocab(source)
    review = ReviewService()
    pv_svc = PersonalVocabService()

    words = svc.random_words(count, band)
    if not words:
        console.print("[yellow]没有足够的单词进行测验。[/yellow]")
        pv_svc.close()
        return

    correct = 0
    total = len(words)

    mode_labels = {"en2zh": "英译中", "zh2en": "中译英", "mix": "混合模式"}
    mode_label = mode_labels[mode]

    if mode == "en2zh":
        console.print(f"\n[bold]词汇测验 ({mode_label})[/bold]  共 {total} 题，输入中文释义（输入 q 退出）\n")
    elif mode == "zh2en":
        console.print(f"\n[bold]词汇测验 ({mode_label})[/bold]  共 {total} 题，输入英文单词（输入 q 退出）\n")
    else:
        console.print(f"\n[bold]词汇测验 ({mode_label})[/bold]  共 {total} 题，随机英译中/中译英（输入 q 退出）\n")

    answered = 0
    mistakes = 0
    try:
        for i, w in enumerate(words, 1):
            # 决定本题模式
            if mode == "mix":
                q_mode = rand_mod.choice(["en2zh", "zh2en"])
            else:
                q_mode = mode

            if q_mode == "en2zh":
                console.print(f"[bold cyan]({i}/{total}) {w.word}[/bold cyan]  {w.phonetic}  [{w.pos}]")
                answer = input("  你的答案 (中文): ").strip()
            else:
                console.print(
                    f"[bold cyan]({i}/{total})[/bold cyan]  "
                    f"[yellow]{w.meaning}[/yellow]  [{w.pos}]"
                )
                answer = input("  你的答案 (英文): ").strip()

            if answer.lower() == "q":
                total = answered
                break

            if q_mode == "en2zh":
                # 英译中：答案包含释义中的关键词即算对
                meanings = w.meaning.replace("；", "，").replace(",", "，").split("，")
                is_correct = any(
                    m.strip() in answer or answer in m.strip()
                    for m in meanings if m.strip()
                )
            else:
                # 中译英：忽略大小写和首尾空格
                is_correct = answer.lower() == w.word.lower()

            if is_correct:
                correct += 1
                console.print("  [green]✓ 正确！[/green]\n")
            else:
                if q_mode == "en2zh":
                    console.print(f"  [red]✗ 错误[/red]  正确答案: [yellow]{w.meaning}[/yellow]\n")
                else:
                    console.print(f"  [red]✗ 错误[/red]  正确答案: [yellow]{w.word}[/yellow]\n")
                # 错词自动收录到个人词库 mistakes 分类
                try:
                    pv_svc.add_mistake(w, source="quiz_mistake")
                    mistakes += 1
                except Exception:
                    pass

            # 记录学习结果
            review.record_learn(w, is_correct)
            answered += 1
    except (KeyboardInterrupt, EOFError):
        console.print("\n[dim]测验中断[/dim]")
        total = answered

    review.close()
    pv_svc.close()

    if total > 0:
        rate = correct / total * 100
        color = "green" if rate >= 80 else "yellow" if rate >= 60 else "red"
        console.print(f"\n[bold]测验结束[/bold]  正确 {correct}/{total}  正确率 [{color}]{rate:.0f}%[/{color}]")
        if mistakes > 0:
            console.print(f"[dim]已将 {mistakes} 个错词收录到错词本[/dim]")


@vocab.command()
@click.option("-n", "--count", default=20, help="复习数量上限", show_default=True)
def review(count: int):
    """复习到期单词"""
    svc = ReviewService()
    due = svc.get_due_words(limit=count)

    if not due:
        console.print("[green]暂无需要复习的单词，继续保持！[/green]")
        svc.close()
        return

    pv_svc = PersonalVocabService()

    console.print(f"\n[bold]复习模式[/bold]  共 {len(due)} 个待复习单词\n")
    console.print("[dim]看到单词后回忆释义，按 Enter 查看答案，输入 y=记得 n=忘了 q=退出[/dim]\n")

    correct = 0
    total = 0
    mistakes = 0

    try:
        for i, item in enumerate(due, 1):
            w = item["word_data"]
            rec = item["record"]

            console.print(
                f"[bold cyan]({i}/{len(due)}) {w.word}[/bold cyan]  "
                f"[dim]记忆等级: {rec.memory_level}  已学: {rec.learn_count}次[/dim]"
            )
            input("  按 Enter 查看答案...")

            console.print(f"  释义: [yellow]{w.meaning}[/yellow]  [{w.pos}]")
            if w.example:
                console.print(f"  [italic]例: {w.example}[/italic]")

            answer = input("  记得吗？(y/n/q): ").strip().lower()
            if answer == "q":
                break

            is_correct = answer == "y"
            if is_correct:
                correct += 1
                console.print("  [green]继续保持！[/green]\n")
            else:
                console.print("  [red]加油，下次会记住的！[/red]\n")
                # 错词自动收录到 mistakes 分类
                try:
                    pv_svc.add_mistake(w, source="review_mistake")
                    mistakes += 1
                except Exception:
                    pass

            svc.record_learn(w, is_correct)
            total += 1
    except (KeyboardInterrupt, EOFError):
        console.print("\n[dim]复习中断[/dim]")

    svc.close()
    pv_svc.close()

    if total > 0:
        rate = correct / total * 100
        console.print(f"\n[bold]复习结束[/bold]  记住 {correct}/{total}  正确率 {rate:.0f}%")
        if mistakes > 0:
            console.print(f"[dim]已将 {mistakes} 个错词收录到错词本[/dim]")


@vocab.command("search")
@click.argument("keyword")
@_source_option
def search_cmd(keyword: str, source: str):
    """搜索单词（支持 word/释义/topic 模糊匹配）"""
    svc = _load_vocab(source)

    results = svc.search_words(keyword)
    if not results:
        console.print(f"[yellow]没有找到包含 '{keyword}' 的单词。[/yellow]")
        return

    source_label = "大词库" if source == "master" else "精选"
    table = Table(title=f"搜索结果: '{keyword}' (共 {len(results)} 个) [{source_label}]", show_lines=True)
    table.add_column("单词", style="bold cyan", min_width=15)
    table.add_column("音标", style="dim")
    table.add_column("词性", style="green", justify="center")
    table.add_column("释义", style="yellow", min_width=15)
    table.add_column("Band", justify="center")
    table.add_column("主题", style="magenta")

    for w in results:
        table.add_row(w.word, w.phonetic, w.pos, w.meaning, str(w.band), w.topic)

    console.print(table)


@vocab.command("list")
@click.option("-b", "--band", type=int, default=None, help="按 band 等级筛选 (5-9)")
@click.option("-t", "--topic", default=None, help="按主题筛选")
@click.option("-p", "--page", default=1, help="页码", show_default=True)
@click.option("--per-page", default=20, help="每页数量", show_default=True)
@_source_option
def list_cmd(band: int | None, topic: str | None, page: int, per_page: int, source: str):
    """浏览词库（支持 band/topic 筛选，分页显示）"""
    svc = _load_vocab(source)

    words, total = svc.list_words(band=band, topic=topic, page=page, per_page=per_page)
    if not words:
        console.print("[yellow]没有找到匹配的单词。[/yellow]")
        return

    total_pages = math.ceil(total / per_page)
    filter_desc = []
    if band is not None:
        filter_desc.append(f"Band {band}")
    if topic is not None:
        filter_desc.append(f"主题: {topic}")
    source_label = "大词库" if source == "master" else "精选"
    filter_desc.append(source_label)
    filter_str = " | ".join(filter_desc)

    table = Table(
        title=f"词库浏览 [{filter_str}]  第 {page}/{total_pages} 页  (共 {total} 个)",
        show_lines=True,
    )
    table.add_column("单词", style="bold cyan", min_width=15)
    table.add_column("音标", style="dim")
    table.add_column("词性", style="green", justify="center")
    table.add_column("释义", style="yellow", min_width=15)
    table.add_column("Band", justify="center")
    table.add_column("主题", style="magenta")

    for w in words:
        table.add_row(w.word, w.phonetic, w.pos, w.meaning, str(w.band), w.topic)

    console.print(table)

    if total_pages > 1:
        console.print(
            f"\n[dim]提示: 使用 --page N 翻页 (共 {total_pages} 页)[/dim]"
        )


@vocab.command("info")
@_source_option
def info_cmd(source: str):
    """显示词库概览（各 Band 数量、主题分布）"""
    svc = _load_vocab(source)

    stats = svc.get_vocab_stats()

    source_label = "大词库 (master)" if source == "master" else "精选 (curated)"

    # Band 分布
    band_table = Table(title=f"词库概览 [{source_label}]", show_lines=False)
    band_table.add_column("Band", justify="center", style="bold")
    band_table.add_column("数量", justify="right", style="cyan")
    band_table.add_column("分布", min_width=20)

    max_band = max(stats["bands"].values()) if stats["bands"] else 1
    for band_level, count in stats["bands"].items():
        bar_len = int(count / max_band * 25) if max_band > 0 else 0
        bar = "█" * bar_len
        band_table.add_row(str(band_level), str(count), f"[cyan]{bar}[/cyan]")

    band_table.add_row("", "", "")
    band_table.add_row("[bold]总计[/bold]", f"[bold]{stats['total']}[/bold]", "")
    console.print(band_table)

    # 主题分布
    topic_table = Table(title="主题分布", show_lines=False)
    topic_table.add_column("主题", style="magenta", min_width=15)
    topic_table.add_column("数量", justify="right", style="cyan")
    topic_table.add_column("分布", min_width=20)

    max_topic = max(stats["topics"].values()) if stats["topics"] else 1
    for topic_name, count in stats["topics"].items():
        bar_len = int(count / max_topic * 25) if max_topic > 0 else 0
        bar = "█" * bar_len
        topic_table.add_row(topic_name, str(count), f"[magenta]{bar}[/magenta]")

    console.print(topic_table)


# ---- 个人词库命令 ----


@vocab.command("add")
@click.argument("word")
@click.option("-m", "--meaning", default=None, help="中文释义")
@click.option("-b", "--band", type=int, default=None, help="Band 等级 (5-9)")
@click.option("--pos", default=None, help="词性")
@click.option("--note", default=None, help="笔记")
@click.option("-c", "--category", default=None, help="添加到分类")
def add_cmd(word: str, meaning: str | None, band: int | None, pos: str | None, note: str | None, category: str | None):
    """添加单词到个人词库（自动从内置词库填充字段）"""
    pv_svc = PersonalVocabService()

    # 尝试从内置词库自动填充
    vocab_svc = VocabService()
    vocab_svc.load_master()
    builtin = vocab_svc.get_word(word)

    pw = PersonalWord(word=word, band=band or (builtin.band if builtin else 5))
    if builtin:
        pw.phonetic = builtin.phonetic
        pw.meaning = meaning or builtin.meaning
        pw.pos = pos or builtin.pos
        pw.topic = builtin.topic
        pw.example = builtin.example
        pw.example_cn = builtin.example_cn
    else:
        pw.meaning = meaning or ""
        pw.pos = pos or ""

    if note:
        pw.note = note

    try:
        result = pv_svc.add_word(pw)
        console.print(f"[green]已添加:[/green] [bold cyan]{result.word}[/bold cyan]  {result.meaning}")
        if builtin:
            console.print("[dim]（已从内置词库自动填充字段）[/dim]")

        if category:
            pv_svc.add_word_to_category(result.word, category)
            console.print(f"[dim]已加入分类: {category}[/dim]")
    except ValueError as e:
        console.print(f"[red]{e}[/red]")
    finally:
        pv_svc.close()


@vocab.command("edit")
@click.argument("word")
@click.option("-m", "--meaning", default=None, help="中文释义")
@click.option("-b", "--band", type=int, default=None, help="Band 等级")
@click.option("--pos", default=None, help="词性")
@click.option("--note", default=None, help="笔记")
def edit_cmd(word: str, meaning: str | None, band: int | None, pos: str | None, note: str | None):
    """编辑个人词库中的单词"""
    pv_svc = PersonalVocabService()
    try:
        result = pv_svc.edit_word(word, meaning=meaning, band=band, pos=pos, note=note)
        console.print(f"[green]已更新:[/green] [bold cyan]{result.word}[/bold cyan]  {result.meaning}")
    except ValueError as e:
        console.print(f"[red]{e}[/red]")
    finally:
        pv_svc.close()


@vocab.command("delete")
@click.argument("word")
@click.confirmation_option(prompt="确定要删除吗？")
def delete_cmd(word: str):
    """从个人词库删除单词"""
    pv_svc = PersonalVocabService()
    if pv_svc.delete_word(word):
        console.print(f"[green]已删除:[/green] {word}")
    else:
        console.print(f"[yellow]未找到单词: {word}[/yellow]")
    pv_svc.close()


@vocab.command("list-personal")
@click.option("-c", "--category", default=None, help="按分类筛选")
@click.option("-p", "--page", default=1, help="页码", show_default=True)
@click.option("--per-page", default=20, help="每页数量", show_default=True)
def list_personal_cmd(category: str | None, page: int, per_page: int):
    """浏览个人词库"""
    pv_svc = PersonalVocabService()
    words, total = pv_svc.list_words(category=category, page=page, per_page=per_page)
    pv_svc.close()

    if not words:
        console.print("[yellow]个人词库为空。使用 'ib vocab add <word>' 添加单词。[/yellow]")
        return

    total_pages = math.ceil(total / per_page)
    title = f"个人词库 (共 {total} 个)"
    if category:
        title += f"  [分类: {category}]"
    title += f"  第 {page}/{total_pages} 页"

    table = Table(title=title, show_lines=True)
    table.add_column("单词", style="bold cyan", min_width=15)
    table.add_column("释义", style="yellow", min_width=15)
    table.add_column("Band", justify="center")
    table.add_column("来源", style="dim")
    table.add_column("笔记", style="green")

    for w in words:
        table.add_row(w.word, w.meaning, str(w.band), w.source, w.note or "—")

    console.print(table)


@vocab.command("category")
@click.argument("action", type=click.Choice(["create", "list", "delete"]))
@click.argument("name", required=False)
@click.option("-d", "--description", default="", help="分类描述")
def category_cmd(action: str, name: str | None, description: str):
    """管理词库分类 (create/list/delete)"""
    pv_svc = PersonalVocabService()
    try:
        if action == "list":
            categories = pv_svc.list_categories()
            if not categories:
                console.print("[yellow]暂无分类。[/yellow]")
                return

            table = Table(title="词库分类", show_lines=False)
            table.add_column("名称", style="bold cyan")
            table.add_column("描述", style="dim")
            table.add_column("词数", justify="right", style="yellow")
            table.add_column("类型", justify="center")

            for c in categories:
                type_label = "[blue]系统[/blue]" if c.is_system else "自定义"
                table.add_row(c.name, c.description, str(c.word_count), type_label)

            console.print(table)

        elif action == "create":
            if not name:
                console.print("[red]请指定分类名称: ib vocab category create <name>[/red]")
                return
            cat = pv_svc.create_category(name, description)
            console.print(f"[green]已创建分类:[/green] [bold]{cat.name}[/bold]")

        elif action == "delete":
            if not name:
                console.print("[red]请指定分类名称: ib vocab category delete <name>[/red]")
                return
            pv_svc.delete_category(name)
            console.print(f"[green]已删除分类:[/green] {name}")

    except ValueError as e:
        console.print(f"[red]{e}[/red]")
    finally:
        pv_svc.close()


@vocab.command("import")
@click.argument("path", type=click.Path(exists=True))
@click.option("-c", "--category", default=None, help="导入后添加到分类")
def import_cmd(path: str, category: str | None):
    """批量导入单词 (支持 JSON/CSV/纯文本)"""
    from pathlib import Path as P
    file_path = P(path)
    pv_svc = PersonalVocabService()

    # 纯文本模式下加载内置词库用于自动匹配
    vocab_svc = None
    if file_path.suffix.lower() not in (".json", ".csv"):
        vocab_svc = VocabService()
        vocab_svc.load_master()

    result = pv_svc.import_words(file_path, vocab_service=vocab_svc)
    console.print(
        f"[green]导入完成:[/green]  "
        f"成功 [bold cyan]{result['imported']}[/bold cyan]  "
        f"跳过 [yellow]{result['skipped']}[/yellow]  "
        f"失败 [red]{result['failed']}[/red]"
    )

    if category and result["imported"] > 0:
        # 将新导入的词添加到分类
        words, _ = pv_svc.list_words(page=1, per_page=999999)
        added = 0
        for w in words:
            if w.source == "import":
                try:
                    pv_svc.add_word_to_category(w.word, category)
                    added += 1
                except (ValueError, Exception):
                    pass
        if added > 0:
            console.print(f"[dim]已将 {added} 个词添加到分类: {category}[/dim]")

    pv_svc.close()


@vocab.command("export")
@click.option("-c", "--category", default=None, help="仅导出指定分类")
@click.option("-f", "--format", "fmt", type=click.Choice(["json", "csv"]), default="json", help="输出格式", show_default=True)
@click.option("-o", "--output", default=None, help="输出文件路径（默认打印到终端）")
def export_cmd(category: str | None, fmt: str, output: str | None):
    """导出个人词库"""
    from pathlib import Path as P
    pv_svc = PersonalVocabService()
    content = pv_svc.export_words(fmt=fmt, category=category)
    pv_svc.close()

    if not content or content == "[]":
        console.print("[yellow]个人词库为空，无内容可导出。[/yellow]")
        return

    if output:
        P(output).write_text(content, encoding="utf-8")
        console.print(f"[green]已导出到:[/green] {output}")
    else:
        console.print(content)
