"""grade 命令组：AI 写作批改"""

from __future__ import annotations

import sys
from pathlib import Path

import click
from rich.console import Console
from rich.panel import Panel
from rich.progress_bar import ProgressBar
from rich.table import Table
from rich.text import Text

from ielts_buddy.services.diff_service import diff_summary, diff_texts
from ielts_buddy.services.grading_service import GradingService

console = Console()

# 评分颜色映射
def _score_color(score: float) -> str:
    if score >= 7.0:
        return "green"
    if score >= 5.5:
        return "yellow"
    return "red"


def _score_bar(label: str, score: float, comment: str) -> str:
    """生成单维度评分展示"""
    color = _score_color(score)
    filled = int(score / 9 * 20)
    bar = "█" * filled + "░" * (20 - filled)
    return f"[bold]{label}[/bold]  [{color}]{bar}  {score:.1f}[/{color}]\n  [dim]{comment}[/dim]"


@click.group("grade")
def grade():
    """AI 写作批改命令"""


# 作文最小字符数（低于此值大概率不是有效作文）
MIN_ESSAY_CHARS = 50


def _validate_essay(text: str) -> str | None:
    """校验作文，返回错误信息（若合法则返回 None）"""
    if not text or not text.strip():
        return "作文内容为空"
    n = len(text.strip())
    if n < MIN_ESSAY_CHARS:
        return (
            f"作文太短（{n} 字符）。IELTS 作文通常至少 150-250 词，"
            f"请输入至少 {MIN_ESSAY_CHARS} 字符的完整段落"
        )
    return None


@grade.command()
@click.option("-t", "--topic", default=None, help="指定写作话题")
def essay(topic: str | None):
    """交互式输入作文并批改（输入完毕后按 Ctrl-D 提交）"""
    console.print("[bold cyan]请输入你的作文[/bold cyan] (输入完毕后按 Ctrl-D 提交)：")
    if topic:
        console.print(f"[dim]话题: {topic}[/dim]\n")

    try:
        lines = []
        while True:
            try:
                line = input()
                lines.append(line)
            except EOFError:
                break
    except KeyboardInterrupt:
        console.print("\n[dim]已取消[/dim]")
        return

    essay_text = "\n".join(lines).strip()
    err = _validate_essay(essay_text)
    if err:
        console.print(f"[yellow]{err}，已取消。[/yellow]")
        return

    _do_grade(essay_text, topic)


@grade.command()
@click.argument("path", type=click.Path(exists=True))
@click.option("-t", "--topic", default=None, help="指定写作话题")
def file(path: str, topic: str | None):
    """从文件读取作文并批改"""
    file_path = Path(path)
    essay_text = file_path.read_text(encoding="utf-8").strip()
    err = _validate_essay(essay_text)
    if err:
        console.print(f"[yellow]{err}。[/yellow]")
        return

    console.print(f"[dim]读取文件: {file_path} ({len(essay_text)} 字符)[/dim]")
    _do_grade(essay_text, topic)


@grade.command()
@click.option("-n", "--limit", default=10, help="显示条数", show_default=True)
def history(limit: int):
    """查看历史批改记录"""
    svc = GradingService()
    records = svc.get_history(limit)
    total = svc.get_history_count()
    avg = svc.get_average_score()
    svc.close()

    if not records:
        console.print("[yellow]暂无批改记录。[/yellow]")
        return

    console.print(f"\n[bold]批改历史[/bold]  共 {total} 条 | 平均分: [bold]{avg:.1f}[/bold]\n")

    table = Table(show_lines=True)
    table.add_column("#", justify="right", style="dim", min_width=3)
    table.add_column("时间", style="cyan", min_width=16)
    table.add_column("总分", justify="center", min_width=5)
    table.add_column("TR", justify="center", min_width=4)
    table.add_column("CC", justify="center", min_width=4)
    table.add_column("LR", justify="center", min_width=4)
    table.add_column("GRA", justify="center", min_width=4)
    table.add_column("话题", style="dim", min_width=10)

    for i, r in enumerate(records, 1):
        color = _score_color(r.overall_score)
        table.add_row(
            str(i),
            (r.graded_at or "")[:16],
            f"[{color}]{r.overall_score:.1f}[/{color}]",
            f"{r.task_response.score:.1f}",
            f"{r.coherence.score:.1f}",
            f"{r.lexical_resource.score:.1f}",
            f"{r.grammar.score:.1f}",
            (r.topic or "—")[:20],
        )

    console.print(table)


def _do_grade(essay_text: str, topic: str | None) -> None:
    """执行批改并展示结果"""
    console.print("\n[bold]正在批改...[/bold] 请稍候\n")

    svc = GradingService()
    try:
        result = svc.grade_essay(essay_text, topic)
    except RuntimeError as e:
        console.print(f"[red]批改失败: {e}[/red]")
        svc.close()
        return
    svc.close()

    # 总分展示
    color = _score_color(result.overall_score)
    score_text = f"[bold {color}]  ★ 总分: {result.overall_score:.1f} / 9.0  [/bold {color}]"
    console.print(Panel(score_text, border_style=color, title="批改结果"))

    # 四维评分
    dims = [
        ("Task Response (审题回应)", result.task_response),
        ("Coherence & Cohesion (连贯衔接)", result.coherence),
        ("Lexical Resource (词汇资源)", result.lexical_resource),
        ("Grammatical Range (语法)", result.grammar),
    ]
    dim_lines = []
    for label, dim in dims:
        dim_lines.append(_score_bar(label, dim.score, dim.comment))

    console.print(Panel("\n\n".join(dim_lines), title="四维评分", border_style="blue"))

    # 改进建议
    if result.suggestions:
        suggestions = "\n".join(f"  [bold]{i}.[/bold] {s}" for i, s in enumerate(result.suggestions, 1))
        console.print(Panel(suggestions, title="改进建议", border_style="yellow"))

    # 高分改写
    if result.rewrite:
        console.print(Panel(result.rewrite, title="高分改写示例", border_style="green"))

    # Diff 对比（原文 vs 改写）
    if result.rewrite and result.essay_text:
        _show_diff(result.essay_text, result.rewrite)


@grade.command("diff")
@click.option("-n", "--index", default=1, help="历史记录编号（1=最近）", show_default=True)
def diff_cmd(index: int):
    """查看历史批改的原文与改写对比"""
    svc = GradingService()
    records = svc.get_history(limit=index)
    svc.close()

    if len(records) < index:
        console.print("[yellow]没有找到对应的批改记录。[/yellow]")
        return

    result = records[index - 1]
    if not result.rewrite:
        console.print("[yellow]该批改记录没有改写内容。[/yellow]")
        return

    console.print(f"\n[bold]差异对比[/bold]  [dim]({(result.graded_at or '')[:16]})[/dim]\n")
    _show_diff(result.essay_text, result.rewrite)


def _show_diff(original: str, rewrite: str) -> None:
    """展示原文与改写的差异对比"""
    rich_diff = diff_texts(original, rewrite)
    console.print(Panel(rich_diff, title="差异对比 (原文 → 改写)", border_style="magenta",
                        subtitle="[red strike]删除[/red strike] [green bold]新增[/green bold]"))

    stats = diff_summary(original, rewrite)
    total_changed = stats["delete"] + stats["insert"] + stats["replace_old"]
    total_chars = stats["equal"] + stats["delete"] + stats["replace_old"]
    change_rate = total_changed / total_chars * 100 if total_chars > 0 else 0
    console.print(
        f"[dim]修改率: {change_rate:.0f}%  |  "
        f"删除: {stats['delete']} 字符  |  "
        f"新增: {stats['insert']} 字符  |  "
        f"替换: {stats['replace_old']}→{stats['replace_new']} 字符[/dim]"
    )
